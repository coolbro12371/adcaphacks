const initialState = {
  amount: 0,
  awayDuration: ''
};

export default function(state = initialState, action) {
  switch (action.type) {
    default:
      return state;
  }
}
